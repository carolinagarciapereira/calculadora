# MathTool (Calculadora Next.js)

Projeto simples de calculadora criado com [Next.js](https://nextjs.org/) e JavaScript puro.

## O que faz
- Opera com: soma, subtração, multiplicação e divisão.
- Layout limpo e funcional com CSS básico.

## Estrutura de arquivos
- `main.js`: componente principal com lógica da calculadora.
- `styles.css`: folhas de estilo aplicadas à interface.
- `package.json`: configuração das dependências e scripts do projeto.

## Para executar
```bash
npm install
npm run dev
```

Depois acesse `http://localhost:3000` no navegador.